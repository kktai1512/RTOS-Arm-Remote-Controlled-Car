#include "MKL25Z4.h"
typedef struct
 { 
	 uint8_t cmd;
	 uint8_t data;
 }myDataPacket;